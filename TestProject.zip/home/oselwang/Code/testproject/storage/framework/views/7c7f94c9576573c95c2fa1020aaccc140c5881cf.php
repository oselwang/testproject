<?php $__env->startSection('content'); ?>
    <div class="jumbotron" style="background-color: #168ccc;">
        <div class="container">
            <h1>Share n Eat</h1>
            <h3>Find And Order Your Favorite Recipe !!</h3>
        </div>
    </div>

    <div class="container">
        <p>
            Lorem ipsum dolor sit amet, consect etu er adipiscing elit enean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
        </p>
        <p>
            Lorem ipsum dolor sit amet, consect etu er adipiscing elit enean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
        </p>
        <p>
            Lorem ipsum dolor sit amet, consect etu er adipiscing elit enean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
        </p>
        <p>
            Lorem ipsum dolor sit amet, consect etu er adipiscing elit enean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
        </p>
        <p>
            Lorem ipsum dolor sit amet, consect etu er adipiscing elit enean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
        </p>
        <p>
            Lorem ipsum dolor sit amet, consect etu er adipiscing elit enean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
        </p>
        <p>
            Lorem ipsum dolor sit amet, consect etu er adipiscing elit enean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
        </p>
        <p>
            Lorem ipsum dolor sit amet, consect etu er adipiscing elit enean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
        </p>
        <p>
            Lorem ipsum dolor sit amet, consect etu er adipiscing elit enean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
        </p>
        <p>
            Lorem ipsum dolor sit amet, consect etu er adipiscing elit enean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
        </p>
        <p>
            Lorem ipsum dolor sit amet, consect etu er adipiscing elit enean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
        </p>
        <p>
            Lorem ipsum dolor sit amet, consect etu er adipiscing elit enean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
        </p>
    </div>


    <div class="jumbotron" style="background-color: #168ccc;">
        <div class="container">
            <h1>Share n Eat</h1>
            <h3>Find And Order Your Favorite Recipe !!</h3>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>